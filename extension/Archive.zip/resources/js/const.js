const ICON_DARK = "resources/ico/16-dark.png";
const ICON_LARGE = "resources/ico/128.png";
const ICON_LIGHT = "resources/ico/16.png";
const OPTIONS_PAGE = "chrome://extensions/?options=" + chrome.i18n.getMessage("@@extension_id");
const WARNING_PAGE = "resources/static/warning.html";
const DEFAULT_NODE = "";